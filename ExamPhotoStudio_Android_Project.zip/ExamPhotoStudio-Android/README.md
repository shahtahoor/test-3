# Exam Photo Studio — Native Android Application

Offline-first photo, signature, document, and PDF preparation toolkit for competitive examinations (NEET PG, INI-CET, UPSC, SSC, Banking, JEE).

## Technology Stack
- **Language**: Kotlin 2.0
- **UI Toolkit**: Jetpack Compose with Material Design 3
- **Camera Integration**: CameraX 1.4
- **Document Access**: Android Storage Access Framework (SAF) & Photo Picker
- **Min SDK**: API 26 (Android 8.0 Oreo)
- **Target SDK**: API 35 (Android 15)

## Build Instructions (Android Studio)
1. Open Android Studio (Ladybug or newer recommended).
2. Choose **File > Open...** and select this directory.
3. Allow Gradle to sync dependencies.
4. Select build variant: **debug** or **release**.
5. Connect your Android device via USB debugging or start an emulator.
6. Click **Run > Run 'app'** (Shift + F10).

## Command Line Build (APK Generation)
```bash
# Build Debug APK
./gradlew assembleDebug

# Output APK path:
# app/build/outputs/apk/debug/app-debug.apk

# Build Release APK
./gradlew assembleRelease

# Output APK path:
# app/build/outputs/apk/release/app-release.apk
```

## Testing Instructions
- Photo Studio: Test importing portrait/landscape photos, crop with 3.5x4.5cm preset, apply background replacement, verify target 20-50 KB file size.
- Signature Studio: Test capturing or importing signatures, verifying automatic whitespace trimming and 10-20 KB compression.
- Document Studio: Test document scanning, perspective corner adjustments, and B&W/grayscale filters.
- PDF Studio: Test multi-image to PDF, page extraction, and merging.
- Security: All operations execute 100% locally on-device. Zero network requests or telemetry.
