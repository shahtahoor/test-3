package com.examphotostudio.app.data

data class ExamSpecification(
    val examId: String,
    val examName: String,
    val conductingBody: String,
    val year: String,
    val photoWidthCm: Float,
    val photoHeightCm: Float,
    val photoDpi: Int,
    val photoMinKb: Int,
    val photoMaxKb: Int,
    val signatureWidthCm: Float,
    val signatureHeightCm: Float,
    val signatureMinKb: Int,
    val signatureMaxKb: Int
)

val OfficialExamList = listOf(
    ExamSpecification(
        examId = "neet-pg",
        examName = "NEET PG",
        conductingBody = "NBEMS",
        year = "2026-2027",
        photoWidthCm = 3.5f,
        photoHeightCm = 4.5f,
        photoDpi = 300,
        photoMinKb = 20,
        photoMaxKb = 50,
        signatureWidthCm = 3.5f,
        signatureHeightCm = 1.5f,
        signatureMinKb = 10,
        signatureMaxKb = 20
    ),
    ExamSpecification(
        examId = "ini-cet",
        examName = "INI-CET",
        conductingBody = "AIIMS New Delhi",
        year = "2026-2027",
        photoWidthCm = 3.5f,
        photoHeightCm = 4.5f,
        photoDpi = 300,
        photoMinKb = 50,
        photoMaxKb = 100,
        signatureWidthCm = 6.0f,
        signatureHeightCm = 3.0f,
        signatureMinKb = 20,
        signatureMaxKb = 100
    ),
    ExamSpecification(
        examId = "upsc-cse",
        examName = "UPSC Civil Services",
        conductingBody = "UPSC",
        year = "2026",
        photoWidthCm = 4.0f,
        photoHeightCm = 4.0f,
        photoDpi = 300,
        photoMinKb = 20,
        photoMaxKb = 300,
        signatureWidthCm = 4.0f,
        signatureHeightCm = 4.0f,
        signatureMinKb = 20,
        signatureMaxKb = 300
    ),
    ExamSpecification(
        examId = "ssc-cgl",
        examName = "SSC CGL / CHSL",
        conductingBody = "Staff Selection Commission",
        year = "2026",
        photoWidthCm = 3.5f,
        photoHeightCm = 4.5f,
        photoDpi = 300,
        photoMinKb = 20,
        photoMaxKb = 50,
        signatureWidthCm = 4.0f,
        signatureHeightCm = 2.0f,
        signatureMinKb = 10,
        signatureMaxKb = 20
    )
)
