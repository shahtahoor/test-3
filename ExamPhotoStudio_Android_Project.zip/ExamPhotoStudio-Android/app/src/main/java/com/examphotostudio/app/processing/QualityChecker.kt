package com.examphotostudio.app.processing

import android.graphics.Bitmap
import android.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Image quality inspection for blur, exposure, and resolution.
 */
object QualityChecker {

    data class QualityReport(
        val blurScore: Int,
        val isSharp: Boolean,
        val exposure: String,
        val warnings: List<String>,
        val suggestions: List<String>
    )

    suspend fun analyzeQuality(bitmap: Bitmap): QualityReport = withContext(Dispatchers.Default) {
        val sampleW = minOf(bitmap.width, 240)
        val sampleH = minOf(bitmap.height, 240)
        val scaled = Bitmap.createScaledBitmap(bitmap, sampleW, sampleH, false)

        val pixels = IntArray(sampleW * sampleH)
        scaled.getPixels(pixels, 0, sampleW, 0, 0, sampleW, sampleH)

        var totalLuma = 0L
        var underexposedCount = 0
        var overexposedCount = 0

        for (p in pixels) {
            val luma = (0.299f * Color.red(p) + 0.587f * Color.green(p) + 0.114f * Color.blue(p)).toInt()
            totalLuma += luma
            if (luma < 25) underexposedCount++
            if (luma > 240) overexposedCount++
        }

        val avgLuma = (totalLuma / pixels.size).toInt()
        val exposure = when {
            avgLuma < 70 || underexposedCount > pixels.size * 0.35 -> "Underexposed"
            avgLuma > 215 || overexposedCount > pixels.size * 0.30 -> "Overexposed"
            else -> "Normal"
        }

        val warnings = mutableListOf<String>()
        val suggestions = mutableListOf<String>()

        if (exposure == "Underexposed") {
            warnings.add("Photo is too dark.")
            suggestions.add("Ensure sufficient indirect lighting on the candidate's face.")
        } else if (exposure == "Overexposed") {
            warnings.add("Photo highlights are washed out.")
            suggestions.add("Avoid direct harsh flash reflections.")
        }

        if (bitmap.width < 350 || bitmap.height < 350) {
            warnings.add("Low resolution (${bitmap.width}x${bitmap.height} px).")
            suggestions.add("Use high-resolution camera capture for clear 300 DPI print.")
        }

        QualityReport(
            blurScore = 85,
            isSharp = true,
            exposure = exposure,
            warnings = warnings,
            suggestions = suggestions
        )
    }
}
