package com.examphotostudio.app.processing

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import kotlin.math.abs

/**
 * Iterative binary search JPEG compressor for strict examination file size boundaries.
 */
object ImageCompressor {

    data class CompressionResult(
        val compressedBytes: ByteArray,
        val actualSizeKb: Float,
        val qualityUsed: Int,
        val isCompliant: Boolean,
        val message: String? = null
    )

    suspend fun compressToRange(
        bitmap: Bitmap,
        minKb: Int,
        maxKb: Int,
        targetKb: Int = (minKb + maxKb) / 2
    ): CompressionResult = withContext(Dispatchers.Default) {
        var lowQuality = 5
        var highQuality = 98
        var bestQuality = 85
        var bestBytes: ByteArray = ByteArray(0)
        var bestDiff = Float.MAX_VALUE

        // Binary search up to 8 iterations
        for (i in 0 until 8) {
            val currentQ = (lowQuality + highQuality) / 2
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, currentQ, stream)
            val bytes = stream.toByteArray()
            val sizeKb = bytes.size / 1024f
            val diff = abs(sizeKb - targetKb)

            if (diff < bestDiff) {
                bestDiff = diff
                bestBytes = bytes
                bestQuality = currentQ
            }

            if (sizeKb > maxKb) {
                highQuality = currentQ
            } else if (sizeKb < minKb) {
                lowQuality = currentQ
            } else {
                if (sizeKb > targetKb) highQuality = currentQ else lowQuality = currentQ
            }
        }

        val actualKb = bestBytes.size / 1024f
        val isCompliant = actualKb in minKb.toFloat()..maxKb.toFloat()
        
        val message = when {
            actualKb > maxKb -> "Image detail is high. Minimum compression yielded ${"%.1f".format(actualKb)} KB (Limit: $maxKb KB)."
            actualKb < minKb -> "Image is clean. Output size is ${"%.1f".format(actualKb)} KB (Min: $minKb KB)."
            else -> "Perfect size compliance at $bestQuality% quality."
        }

        CompressionResult(
            compressedBytes = bestBytes,
            actualSizeKb = actualKb,
            qualityUsed = bestQuality,
            isCompliant = isCompliant,
            message = message
        )
    }

    /**
     * Rescales a bitmap to exact pixel dimensions (derived from physical mm/cm/in + DPI).
     */
    fun resizeExact(bitmap: Bitmap, targetWidth: Int, targetHeight: Int): Bitmap {
        return Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
    }
}
